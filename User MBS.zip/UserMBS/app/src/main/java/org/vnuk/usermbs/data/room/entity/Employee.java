package org.vnuk.usermbs.data.room.entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity(tableName = "employees")
public class Employee {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "employee_id")
    private Long employeeID;

    private String firstName;
    private String lastName;
    private String code;
    private String city;
    private String warehouse;
}
