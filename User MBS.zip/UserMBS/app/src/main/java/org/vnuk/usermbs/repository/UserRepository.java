package org.vnuk.usermbs.repository;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import org.vnuk.usermbs.data.room.WarehouseDB;
import org.vnuk.usermbs.data.room.entity.User;

public class UserRepository {
    private static final String TAG = UserRepository.class.getSimpleName();

    private static UserRepository instance;
    private final WarehouseDB mDatabase;
    private MutableLiveData<User> mldUser;

    public UserRepository(@NonNull Application application) {
        mDatabase = WarehouseDB.getInstance(application);
        mldUser = new MutableLiveData<>();
        Log.v(TAG, "Finished creating.");
    }

    public void insert(User user) {
        System.out.println("Insert User in Repo");
        WarehouseDB.databaseWriteExecutor.execute(() -> {
            mDatabase.getUserDao().insert(user);
        });
    }

    public void fetchUserByName(String name) {
        System.out.println("fetchUserByName");
        WarehouseDB.databaseWriteExecutor.execute(() -> {
            User user = mDatabase.getUserDao().getUserByName(name);
            System.out.println("User name is: " + user.getName());
            this.mldUser.postValue(user);
        });
    }

    public void fetchUserByUserName(String userName) {
        System.out.println("fetchUserByUserName");
        WarehouseDB.databaseWriteExecutor.execute(() -> {
            User user = mDatabase.getUserDao().getUserByUserName(userName);
            this.mldUser.postValue(user);
        });
    }


    public MutableLiveData<User> getMldUser() {
        return mldUser;
    }
}
