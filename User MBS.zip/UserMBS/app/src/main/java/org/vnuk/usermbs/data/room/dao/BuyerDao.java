package org.vnuk.usermbs.data.room.dao;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;

import org.vnuk.usermbs.data.room.entity.Buyer;

import java.util.List;

@Dao
public interface BuyerDao {
    @Query("SELECT * FROM buyers")
    List<Buyer> getAll();

//    @Query("SELECT * FROM formulas WHERE tex =:tex")
//    Formula findByTex(String tex);

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    void insert(Buyer buyer);

    @Update
    void update(Buyer buyer);

    @Delete
    void delete(Buyer buyer);

    @Delete
    void delete(Buyer... buyers);
}
