package org.vnuk.usermbs.ui;

public class SomeClass {
}
