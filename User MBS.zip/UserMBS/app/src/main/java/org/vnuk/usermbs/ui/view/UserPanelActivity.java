package org.vnuk.usermbs.ui.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import org.vnuk.usermbs.R;

public class UserPanelActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_panel);
    }
}