package org.vnuk.usermbs;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;

import org.vnuk.usermbs.ui.view.CreateUserActivity;
import org.vnuk.usermbs.ui.view.LogInFragment;
import org.vnuk.usermbs.ui.view.UserPanelActivity;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.v(TAG, "OnCreate.");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btnNewUser = findViewById(R.id.btn_new_user);
        btnNewUser.setOnClickListener(v -> onBtnNewUserClick());
    }

    private void onBtnNewUserClick() {
        Log.i(TAG, "Valid password was given, starting MapActivity.");
        Intent mapActivityIntent = new Intent(this, CreateUserActivity.class);
        startActivity(mapActivityIntent);
    }
}

/*
Potrebno je napraviti sledecu Android aplikaciju. Koristiti MVVM arhitekturu i Repository pattern :
1.	Kreirati bazu podataka sa sledecim tabelama: Korisnik, Zaposleni, Kupac (dodati tabele po potrebi).
Preporuceno je koristiti Room, SqLite ili Google Firebase (Cloud Firestore).
2.	Napraviti formu za registraciju korisnika: ime, user, password.
3.	Napraviti formu za LogIn registrovanih korisnika.
4.	Nakon login-a napraviti formu za unos zaposlenog: ime, prezime, šifra, grad, magacin.
Potrebno je omoguciti da zaposlenom moze biti dodeljeno vise magacina.
5.	Napraviti formu za unos kupaca: naziv, PIB, sifra, zaposleni kome kupac pripada.
6.	Napraviti formu za pregled kupaca (izborom zaposlenog iz comboboxa prikazuje se lista svih njegovih kupaca).
7.	Na posebnoj formi implementirati pozivanje nekog web servisa koji kao rezultata vraca JSON i
prikaz obradjenih podataka. (npr. vremenska prognoza – Openweathermap). U implementaciji ovoga koristiti Retrofit
biblioteku. Rezultate prikazati u RecyclerView-u.

 */