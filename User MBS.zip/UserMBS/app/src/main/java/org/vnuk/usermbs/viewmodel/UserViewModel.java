package org.vnuk.usermbs.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import org.vnuk.usermbs.data.room.entity.User;
import org.vnuk.usermbs.repository.UserRepository;

public class UserViewModel extends AndroidViewModel {
    private UserRepository userRepository;
    private MutableLiveData<User> mldUser;
    public MutableLiveData<String> name;
    public MutableLiveData<String> userName;
    public MutableLiveData<String> password;
    public MutableLiveData<String> mldError;

    public UserViewModel(@NonNull Application application) {
        super(application);
        userRepository = new UserRepository(application);
        mldUser = userRepository.getMldUser();
        name = new MutableLiveData<>();
        userName = new MutableLiveData<>();
        password = new MutableLiveData<>();
        mldError = new MutableLiveData<>();
    }

    public void insertUser(User user){
        System.out.println("Insert User in VM");
        userRepository.insert(user);
    }

    public void fetchUserByName(String name){
        System.out.println("Fetch User in VM");
        userRepository.fetchUserByName(name);
    }

    public void fetchUserByUserName(String userName){
        userRepository.fetchUserByUserName(userName);
    }


    public void onNewUserClick() {


        System.out.println("Name value: " + name.getValue());
/*
                User user = new User(email.getValue(), password.getValue());

                if (!user.isEmailValid()) {
                    errorEmail.setValue("Enter a valid email address");
                } else {
                    errorEmail.setValue(null);
                }

                if (!user.isPasswordLengthGreaterThan5())
                    errorPassword.setValue("Password Length should be greater than 5");
                else {
                    errorPassword.setValue(null);
                }

                userMutableLiveData.setValue(user);
*/

    }

    public MutableLiveData<User> getMldUser() {
        return mldUser;
    }
}
