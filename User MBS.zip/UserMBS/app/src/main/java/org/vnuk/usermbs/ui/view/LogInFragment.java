package org.vnuk.usermbs.ui.view;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.vnuk.usermbs.R;

public class LogInFragment extends Fragment {
    private static final String TAG = LogInFragment.class.getSimpleName();

    public static final String PASSWORD_VALUE = "password_value";

    private EditText etPassword;
    private Button btnLogIn;
    //private PasswordViewModel passwordViewModel;
    //private Helper helper;

    public LogInFragment() {
        super(R.layout.fragment_login);
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        Log.v(TAG, "OnCreate.");
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        Log.v(TAG, "OnViewCreated.");
        //helper = new Helper();
        setupViewModel();
        etPassword = view.findViewById(R.id.et_password);
        btnLogIn = view.findViewById(R.id.btn_submit_login);
        btnLogIn.setOnClickListener(v -> onBtnSubmitClick());
    }

    private void setupViewModel() {
        Log.v(TAG, "Setting up ViewModel.");
/*
        passwordViewModel = new ViewModelProvider(this).get(PasswordViewModel.class);
        passwordViewModel.getMldPassword().observe(getViewLifecycleOwner(), password -> {
            if (!TextUtils.isEmpty(password)) {
                startUserPanelActivity(password);
            } else {
                Log.v(TAG, "User given password does not fulfill all requirements.");
                helper.alerter(getContext(), R.string.password_error_title, R.string.password_error_msg);
            }
        });

 */
    }

    private void onBtnSubmitClick() {
/*
        // Assuming App is only operational when device is connected to internet,
        // user is informed to connect device.
        Log.v(TAG, "Checking if device is connected to internet.");
        if (!helper.isDeviceConnected(getActivity())) {
            Log.e(TAG, "Device is not connected to internet.");
            helper.alerter(getActivity(), R.string.no_internet_title, R.string.no_internet_msg);
            // In case MapActivity is started without internet, there would be no locations on map
            // and only cached tiles will be shown.
            return;
        }
        String passValue = etPassword.getText().toString();
        passwordViewModel.submitPassword(passValue);
 */
        startUserPanelActivity("Pis maco!");
    }

    private void startUserPanelActivity(String passValue) {
        Log.i(TAG, "Valid password was given, starting MapActivity.");
        Intent mapActivityIntent = new Intent(getContext(), UserPanelActivity.class);
        mapActivityIntent.putExtra(PASSWORD_VALUE, passValue);
        startActivity(mapActivityIntent);
    }
}
