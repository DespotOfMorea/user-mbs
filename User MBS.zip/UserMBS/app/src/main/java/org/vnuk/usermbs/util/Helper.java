package org.vnuk.usermbs.util;

import android.content.Context;

import androidx.appcompat.app.AlertDialog;

/**
 * Contains useful methods that are used all over App.
 */
public class Helper {

    public void alerter(Context context, int titleID, int messageID) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(context.getString(titleID));
        builder.setMessage(context.getString(messageID));
        builder.setNeutralButton(context.getString(android.R.string.ok),
                (dialog, which) -> dialog.dismiss());
        builder.create().show();
    }

}
