package org.vnuk.usermbs.data.room;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import org.vnuk.usermbs.data.room.dao.BuyerDao;
import org.vnuk.usermbs.data.room.dao.EmployeeDao;
import org.vnuk.usermbs.data.room.dao.UserDao;
import org.vnuk.usermbs.data.room.entity.Buyer;
import org.vnuk.usermbs.data.room.entity.Employee;
import org.vnuk.usermbs.data.room.entity.User;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Database(entities = {User.class, Employee.class, Buyer.class}, version = 1, exportSchema = false)
public abstract class WarehouseDB extends RoomDatabase {
    private static final String DB_NAME = "warehouse_db";
    private static final int NUMBER_OF_THREADS = 4;
    private static volatile WarehouseDB instance;

    public abstract UserDao getUserDao();
    public abstract EmployeeDao getEmployeeDao();
    public abstract BuyerDao getBuyerDao();

    public static final ExecutorService databaseWriteExecutor =
            Executors.newFixedThreadPool(NUMBER_OF_THREADS);

    public static WarehouseDB getInstance(Context context) {
        if (null == instance) {
            synchronized (WarehouseDB.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(context.getApplicationContext(), WarehouseDB.class, DB_NAME)
                            .build();
                }
            }
        }
        return instance;
    }
}
