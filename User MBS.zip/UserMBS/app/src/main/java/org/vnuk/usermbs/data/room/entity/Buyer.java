package org.vnuk.usermbs.data.room.entity;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity(tableName = "buyers")
public class Buyer {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "buyer_id")
    private Long buyerID;

    private String name;
    private long pib;
    private String code;
    @Ignore
    private Employee employee;
}
